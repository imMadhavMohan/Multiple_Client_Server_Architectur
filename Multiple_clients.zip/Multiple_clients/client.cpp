#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

using namespace std;

#define PORT 8075

int main(){
	int cli_sock = socket(AF_INET, SOCK_STREAM, 0);
	
	if(cli_sock < 0){
		cout<<("[-]Error in connection.\n");
		exit(1);
	}
	cout<<("[+]Client Socket is created.\n");
	
	struct sockaddr_in Addr;	
	memset(&Addr, '\0', sizeof(Addr));
	Addr.sin_family = AF_INET;
	Addr.sin_port = htons(PORT); // convert PORT to host byte order to network byte order
	
	
	string ip_addr = "127.0.0.1";
	
	Addr.sin_addr.s_addr = inet_addr(ip_addr.c_str()); 
	// inet_addr() function shall convert the string into the standard IPv4 dotted decimal notation

	int ret = connect(cli_sock, (struct sockaddr*)&Addr, sizeof(Addr));
	if(ret < 0){
		cout<<("[-]Error in connection.\n");
		exit(1);
	}
	cout<<("[+]Connected to Server.\n");

	char buffer[4096];

	while(true){
		cout<<("Client>> ");
		cin.getline(buffer,sizeof(buffer));
		send(cli_sock, buffer, strlen(buffer), 0); // always take a cstr

		if(strcmp(buffer, ":exit") == 0){
			close(cli_sock);
			cout<<("[-]Disconnected from server.\n");
			exit(1);
		}

		if(recv(cli_sock, buffer, sizeof(buffer), 0) < 0){
			cout<<("[-]Error in receiving data.\n");
		}else{
			cout<<"Server>> "<<buffer<<'\n';
		}
	}

	return 0;
}