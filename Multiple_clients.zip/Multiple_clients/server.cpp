#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>

using namespace std;

#define PORT 8075

int main(){

	int sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	
	if(sockfd < 0){
		cout<<"[-]Error in connection.\n";
		exit(1);
	}
	cout<<"[+]Server Socket is created.\n";
	
	struct sockaddr_in serverAddr;
	memset(&serverAddr, '\0', sizeof(serverAddr));
	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(PORT); // converts the port number from host byte order to network byte order               							.
	string ip_addr = "127.0.0.1";
	serverAddr.sin_addr.s_addr = inet_addr(ip_addr.c_str()); 
	// inet_addr() function shall convert the string into the standard IPv4 dotted decimal notation

	int ret = bind(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
	if(ret < 0){
		cout<<"[-]Error in binding.\n";
		exit(1);
	}
	cout<<"[+]Bind to port "<<PORT<<endl;

	if(listen(sockfd, 10) == 0){
		cout<<"[+]Listening....\n";
	}else{
		cout<<"[-]Error in binding.\n";
	}

	int newSocket;
	struct sockaddr_in newAddr;
	socklen_t addr_size = sizeof(newAddr);

	char buffer[4096];
	pid_t cpid; // child id

	while(true){
		newSocket = accept(sockfd, (struct sockaddr*)&newAddr, &addr_size);
		if(newSocket < 0){
			exit(1);
		}
		cout<<"Connection accepted from: "<<inet_ntoa(newAddr.sin_addr)<<':'<<ntohs(newAddr.sin_port)<<'\n';

		if((cpid = fork()) == 0){ // child exec
			close(sockfd);

			while(true){
				recv(newSocket, buffer, sizeof(buffer), 0);
				if(strcmp(buffer, ":exit") == 0){
					cout<<"Disconnected from "<<inet_ntoa(newAddr.sin_addr)<<':'<< ntohs(newAddr.sin_port);
					// inet_ntoa() converts the Internet host address in, given in network byte
					break;
				}else{
					cout<<"Client>> "<< buffer<<'\n';
					send(newSocket, buffer, strlen(buffer), 0);
					bzero(buffer, sizeof(buffer)); // initialize buffer with null
				}
			}
		}

	}

	close(newSocket);

	return 0;
}